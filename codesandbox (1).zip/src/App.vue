<template>
  <div id="app">
    <nav>
      <router-link to="/App">Ruminations</router-link>
      <router-link to="/components/calendar">Consultations</router-link>
      <router-link to="/components/signup">Collaborations</router-link>
    </nav>
    <router-view></router-view>
  </div>
</template>


<script>
import Vue from "vue";
import VueRouter from "vue-router";

const Ruminations = {
  template: "<div>Ruminations</div>"
};

const Consultations = {
  template: "<div>Consultations</div>"
};

const Collaborations = {
  template: "<div>Collaborations</div>"
};

const router = new VueRouter({
  routes: [
    { path: "/", component: Ruminations },
    { path: "/login", component: Consultations },
    { path: "/about", component: Collaborations }
  ]
});

new Vue({
  router
}).$mount("#app");
</script>




<style scoped>
@import "/src/assets/css/space.css";

#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
