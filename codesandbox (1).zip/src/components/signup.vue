const app = new Vue({
  el: '#signup-form',

  // our data
  data: {
    name: '',
    email: ''
  }
});

<input 
  type="text"
  class="input" 
  name="name"
  v-model="name">

...

<input 
  type="email" 
  class="input" 
  name="email" 
  v-model="email">
...

<form id="signup-form" @submit.prevent="processForm">

see https://scotch.io/courses/getting-started-with-vue/processing-a-form-with-vue