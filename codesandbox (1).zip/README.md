See guides and examples at following links:
blog posts: https://codesandbox.io/s/m7koowq039

calendar usage with events: https://fullcalendar.io/docs/timegrid-view
https://fullcalendar.io/docs/event-popover
https://fullcalendar.io/docs/vue
working calendar example: https://codesandbox.io/s/8xyz32l0r8

router usage: https://flaviocopes.com/vue-router/
https://scotch.io/tutorials/getting-started-with-vue-router

Forms usage/sign up: https://logrocket.com/blog/an-imperative-guide-to-forms-in-vue-js-2/
https://scotch.io/courses/getting-started-with-vue/processing-a-form-with-vue

To add:
paypall checkout and cart (https://vuejsexamples.com/paypal-payment-module-for-vue-storefront/)

MongoDB for storing submitted form data (https://www.djamware.com/post/5a1b779f80aca75eadc12d6e/mongo-express-vue-nodejs-mevn-stack-crud-web-application)
https://flaviocopes.com/node-mongodb/

Please feel free to use this code (when completed) in your own proffesional life. Write articles, sell consultations, build a network.
